import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from './admin.model';



@Injectable({
  providedIn: 'root'
})
export class AdminService {

  passwordToUpdate;

  constructor(private httpClient: HttpClient) { }
  
    adminLogin(adminEmail, password) {
      return this.httpClient.get<Admin>(`http://localhost:8090/loginAdmin/` + adminEmail + '/' + password);
    }


  }
