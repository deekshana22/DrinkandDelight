export class Admin {
 
        adminId: number;
        adminName: string;
        adminpassword: string;
        adminEmail: string;
        userType: string;
    }

