import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }
  error = null;
  ngOnInit(): void {
  }
  onSubmit(loginForm: NgForm){
    this.error = null;
    console.log(loginForm.value);
    this.userService.userLogin(loginForm.value.userEmail, loginForm.value.password).subscribe(data =>{
      console.log(data);
      localStorage.setItem('key', JSON.stringify(data));
      this.router.navigateByUrl('/');
      alert("Login successful");
    }, err => {
      console.log(err);
      this.error = err;
    });
    loginForm.reset();
  }

}
