import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Admin } from '../admin.model';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-login-admin',
  templateUrl: './login-admin.component.html',
  styleUrls: ['./login-admin.component.css']
})
export class LoginAdminComponent implements OnInit {

  constructor( private router: Router, private adminService: AdminService) { }
  error = null;
  ngOnInit(): void {
  }
  onSubmit(loginForm: NgForm) {
    this.error = null;
    console.log(loginForm.value);
    this.adminService.adminLogin(loginForm.value.adminEmail, loginForm.value.adminPassword).subscribe(data =>{
      console.log(data);
      const admin:Admin = data;
      admin.userType = "ADMIN";
      localStorage.setItem('key', JSON.stringify(admin));
      alert("motu");
      this.router.navigateByUrl('/');
    }, err => {
      console.log(err);
      this.error = err;
    });
  }

}

