import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productstock',
  templateUrl: './productstock.component.html',
  styleUrls: ['./productstock.component.css']
})
export class ProductstockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
