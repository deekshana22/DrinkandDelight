import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from './admin.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DrinkAndDelightManagement';
  userName:string;
  constructor(private router: Router){

}
isAdminLogin() {
  const admin:Admin = JSON.parse(localStorage.getItem('key'));
  if (admin && admin.userType == "ADMIN") {
    console.log(admin);
    this.userName = admin.adminName;
    return true;
  } else {
    console.log("admin provider not found");
    return false;
  }
  
}
logout() {
  localStorage.removeItem('key');
  this.router.navigateByUrl('/');
}}