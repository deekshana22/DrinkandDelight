import { Admin } from './admin.model';

describe('Admin', () => {
  it('should create an instance', () => {
    expect(new Admin()).toBeTruthy();
  });
});
